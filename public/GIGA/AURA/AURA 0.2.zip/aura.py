#!/usr/bin/env python3
"""
AURA — Folder-based field protocol.

Your folder IS your node. Its files ARE your aura.
No addresses. No HTML. Any language.

Commands:
  aura mount <folder>          Mount a folder into the AURA field
  aura seek <query>            Find folders that resonate
  aura open <node_id|name>     Run the entry point of a matched node
  aura ls <node_id|name>       List files in a matched node
  aura scan <folder>           Show what aura a folder would emit
  aura field                   Interactive REPL — live field session
  aura watch                   Passively watch the field
  aura new <folder> [lang]     Scaffold a new AURA node folder

Entry point files (aura.py / aura.sh / aura.js / any language):
  Put one of these in your folder. It runs when someone "opens" your node.
  It's like index.html — but any language, executed locally.
"""

import sys
import os
import time
import json
import shutil
import subprocess
import threading

sys.path.insert(0, "/home/claude/aura")
from aura_folder import FolderAura, ENTRY_POINTS, RUNNERS
from aura_field  import AuraField

# ── Colors ────────────────────────────────────────────────────────────────
R = "\033[0m"
BOLD = "\033[1m"; DIM = "\033[2m"
PUR  = "\033[35m"; CYAN = "\033[36m"; GRN  = "\033[32m"
YEL  = "\033[33m"; WHT  = "\033[97m"; RED  = "\033[31m"
PINK = "\033[95m"

def c(col, t): return f"{col}{t}{R}"
def bar(v, w=18):
    n = int(v * w)
    return c(PUR, "█"*n) + c(DIM, "░"*(w-n))

BANNER = f"""
{PUR}  ╔════════════════════════════════════════════╗
  ║  {WHT}A U R A{PUR}  ·  folder field protocol v0.2   ║
  ║  {DIM}Your folder IS the node. Any language.{PUR}    ║
  ╚════════════════════════════════════════════╝{R}
  {DIM}No addresses · No HTML · No index · Just files{R}
"""

# ── Session ───────────────────────────────────────────────────────────────
SESSION = os.path.expanduser("~/.aura_mount.json")

def save_mount(path: str, name: str):
    with open(SESSION, "w") as f:
        json.dump({"path": path, "name": name}, f)

def load_mount():
    if os.path.exists(SESSION):
        try:
            with open(SESSION) as f:
                d = json.load(f)
            return d["path"], d.get("name")
        except: pass
    return None, None

# ── Scaffold templates ─────────────────────────────────────────────────────
TEMPLATES = {
    "py": (
        "aura.py",
        '''#!/usr/bin/env python3
"""
This is my AURA node entry point.
Run when someone 'opens' this folder from the field.
"""
import os

node = os.environ.get("AURA_NODE", ".")
print(f"Welcome to {os.path.basename(node)}")
print()
print("Files in this node:")
for f in sorted(os.listdir(node)):
    if not f.startswith("."):
        print(f"  {f}")
'''
    ),
    "sh": (
        "aura.sh",
        '''#!/bin/bash
# AURA node entry point — shell edition
echo "Welcome to $(basename $AURA_NODE)"
echo
echo "Files:"
ls -1 "$AURA_NODE"
'''
    ),
    "js": (
        "aura.js",
        '''// AURA node entry point — Node.js edition
const fs = require('fs');
const path = require('path');
const node = process.env.AURA_NODE || '.';
console.log(`Welcome to ${path.basename(node)}`);
console.log();
console.log('Files:');
fs.readdirSync(node).filter(f => !f.startsWith('.')).forEach(f => console.log(' ', f));
'''
    ),
    "rs": (
        "aura.rs",
        '''// AURA node entry — Rust edition
// Compile: rustc aura.rs -o aura && chmod +x aura
use std::env;
use std::fs;
fn main() {
    let node = env::var("AURA_NODE").unwrap_or(".".into());
    println!("Welcome to {}", std::path::Path::new(&node).file_name().unwrap().to_str().unwrap());
    println!();
    println!("Files:");
    if let Ok(entries) = fs::read_dir(&node) {
        for entry in entries.flatten() {
            let name = entry.file_name();
            let s = name.to_str().unwrap_or("");
            if !s.starts_with('.') { println!("  {}", s); }
        }
    }
}
'''
    ),
}

DEFAULT_META = """\
name: {name}
description: An AURA node
tags: {tags}
author:
"""

# ── Commands ──────────────────────────────────────────────────────────────

def cmd_scan(folder: str):
    """Show what aura a folder would emit — dry run."""
    print(f"\n  {DIM}Scanning: {folder}{R}\n")
    try:
        fa = FolderAura(folder).scan()
    except FileNotFoundError as e:
        print(f"  {RED}✗ {e}{R}\n"); return

    s = fa.summary()
    print(f"  {c(WHT+BOLD, s['name'])}  {c(DIM, s['path'])}")
    if s['description']:
        print(f"  {c(DIM, s['description'])}")
    print()
    entry = s['entry'] or c(DIM, "none — add aura.py / aura.sh / aura.js")
    print(f"  Entry point : {c(CYAN, entry)}")
    print(f"  Files       : {s['file_count']}")
    print(f"  Fingerprint : {c(DIM, s['fingerprint'])}")
    print()
    print(f"  {c(PUR, 'Aura tags:')}")
    for tag, w in sorted(s['tags'].items(), key=lambda x: -x[1]):
        print(f"  {bar(w, 14)}  {c(WHT, tag):<22} {c(DIM, f'{w:.2f}')}")
    print()


def cmd_new(folder: str, lang: str = "py"):
    """Scaffold a new AURA node folder."""
    lang = lang.lower().lstrip(".")
    p    = os.path.abspath(folder)
    name = os.path.basename(p)

    if os.path.exists(p):
        print(f"  {YEL}⚠ Folder already exists — adding AURA files{R}")
    else:
        os.makedirs(p)
        print(f"  {GRN}✓ Created {p}{R}")

    # write entry point
    if lang in TEMPLATES:
        fname, content = TEMPLATES[lang]
        ep = os.path.join(p, fname)
        with open(ep, "w") as f:
            f.write(content)
        os.chmod(ep, 0o755)
        print(f"  {GRN}✓ Entry point: {fname}{R}")
    else:
        print(f"  {YEL}⚠ Unknown lang '{lang}' — supported: {', '.join(TEMPLATES)}{R}")
        print(f"    Just add a file named 'aura.<ext>' and AURA will figure it out.")

    # write meta
    meta_path = os.path.join(p, "aura.meta")
    if not os.path.exists(meta_path):
        with open(meta_path, "w") as f:
            f.write(DEFAULT_META.format(name=name, tags=lang+", code"))
        print(f"  {GRN}✓ aura.meta created (edit tags/description){R}")

    # data/ dir
    data = os.path.join(p, "data")
    if not os.path.exists(data):
        os.makedirs(data)
        print(f"  {GRN}✓ data/ folder created — put your files here{R}")

    print(f"\n  {c(PUR, 'Your node is ready:')} {p}")
    print(f"  Mount it: {c(WHT, f'aura mount {p}')}")
    print(f"  Scan it:  {c(WHT, f'aura scan {p}')}\n")


def cmd_mount(folder: str):
    """Mount a folder into the AURA field."""
    folder = os.path.abspath(folder)
    if not os.path.exists(folder):
        print(f"  {RED}✗ Folder not found: {folder}{R}"); return

    print(f"\n  Scanning folder...")
    try:
        fa = FolderAura(folder).scan()
    except Exception as e:
        print(f"  {RED}✗ {e}{R}"); return

    name = fa.meta.get("name", os.path.basename(folder))
    save_mount(folder, name)
    s = fa.summary()

    print(f"\n  {c(GRN, '◉')} Mounted: {c(WHT+BOLD, name)}")
    print(f"  {c(DIM, folder)}")
    print(f"\n  Aura: {', '.join(list(s['tags'].keys())[:8])}")
    print(f"  Files: {s['file_count']}  |  Entry: {s['entry'] or 'none'}")
    print(f"\n  {c(DIM, 'This folder is now your AURA node. Run: aura field')}\n")


def _field_session(field: AuraField):
    """Interactive REPL inside the field."""
    print(BANNER)
    s = field.folder.summary()
    print(f"  {c(GRN,'◉')} {c(WHT+BOLD, field.name)}  {c(DIM, '['+field.node_id+']')}")
    print(f"  {c(DIM, str(field.folder.path))}")
    print(f"  Aura: {c(PUR, ', '.join(list(s['tags'].keys())[:6]))}")
    print(f"\n  {c(DIM,'seek · ls · open · who · scan · refresh · help · quit')}\n")

    # live event display
    def on_peer(pid, name, summary):
        tags = list(summary.get("tags", {}).keys())[:4]
        print(f"\n  {c(GRN,'→')} {c(WHT,name)} entered the field  {c(DIM, ' '.join(tags))}")
        print("  > ", end="", flush=True)

    def on_seek(pid, name, query, score):
        if score > 0.1:
            print(f"\n  {c(YEL,'◎')} {c(WHT,name)} seeks '{query}'  {c(PUR, f'you resonate {score:.0%}')}")
            print("  > ", end="", flush=True)

    field.on_peer(on_peer)
    field.on_seek(on_seek)

    while True:
        try:
            raw = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not raw:
            continue

        parts = raw.split(None, 1)
        cmd   = parts[0].lower()
        arg   = parts[1].strip() if len(parts) > 1 else ""

        # ── seek ──────────────────────────────────────────────────────────
        if cmd in ("seek", "s"):
            if not arg: print(f"  {DIM}seek <what>{R}"); continue
            print(f"\n  {c(YEL,'◎')} Seeking '{arg}'...\n")
            results = field.seek(arg)
            time.sleep(1.2)
            results = field.seek(arg)
            if not results:
                print(f"  {c(DIM,'No resonance found. Field may be empty or no peers match.')}")
            else:
                for r in results:
                    desc = r.get("description","") or ""
                    tags = "  ".join(r["tags"][:5])
                    print(f"  {bar(r['score'])}  {c(WHT+BOLD, r['name']):<16}  {c(DIM,'['+r['node_id']+']')}")
                    if desc: print(f"  {'':20}{c(DIM, desc)}")
                    print(f"  {'':20}{c(DIM, tags)}")
                    entry = r.get('entry')
                    if entry: print(f"  {'':20}{c(CYAN,'entry: '+entry)}")
                    print()

        # ── ls — list files of a node ──────────────────────────────────────
        elif cmd == "ls":
            if not arg:
                # list own folder
                for f in field.folder.files:
                    sz = f['size']
                    sz_str = f"{sz//1024}K" if sz > 1024 else f"{sz}B"
                    print(f"  {c(CYAN, f['path']):<40} {c(DIM, sz_str)}")
            else:
                # find peer, list their files
                peers = field.peers_list()
                matched = [p for p in peers if arg.lower() in p['name'].lower() or arg == p['node_id']]
                if not matched:
                    print(f"  {c(DIM,'Node not found: '+ arg)}")
                else:
                    p = matched[0]
                    # request their listing
                    summary = field.peers.get(p['node_id'], {}).get('summary', {})
                    print(f"\n  {c(WHT+BOLD, p['name'])}  —  {p['files']} files\n")
                    # we only have summary-level data without direct file transfer
                    print(f"  {c(DIM,'(File transfer not yet implemented — showing aura tags)')}")
                    for tag in p['tags']:
                        print(f"  {c(PUR,'◦')} {tag}")
            print()

        # ── open — run another node's entry point ──────────────────────────
        elif cmd in ("open", "run", "visit"):
            if not arg:
                # run own entry
                proc = field.folder.run_entry()
                if not proc:
                    print(f"  {c(YEL,'No entry point in your folder. Add aura.py / aura.sh / etc.')}")
                else:
                    print(f"\n  {c(GRN,'▶')} Running {field.folder.entry.name}\n  {'─'*40}")
                    for line in proc.stdout:
                        print(f"  {line}", end="")
                    print(f"  {'─'*40}\n")
            else:
                # find peer by name
                peers = field.peers_list()
                matched = [p for p in peers if arg.lower() in p['name'].lower()]
                if not matched:
                    print(f"  {c(DIM,'Node not found in field: '+arg)}")
                    continue
                peer = matched[0]
                path = field.peers.get(peer['node_id'], {}).get('summary', {}).get('path')
                if not path or not os.path.exists(path):
                    print(f"  {c(YEL,'Cannot open remote node — only local nodes can be run')}")
                    print(f"  {c(DIM,'(Remote execution is a future protocol extension)')}")
                else:
                    fa = FolderAura(path).scan()
                    proc = fa.run_entry()
                    if not proc:
                        print(f"  {c(YEL,'No entry point found in that node')}")
                    else:
                        print(f"\n  {c(GRN,'▶')} Running {c(WHT,peer['name'])}/{fa.entry.name}\n  {'─'*40}")
                        for line in proc.stdout:
                            print(f"  {line}", end="")
                        print(f"  {'─'*40}\n")

        # ── who ────────────────────────────────────────────────────────────
        elif cmd == "who":
            peers = field.peers_list()
            if not peers:
                print(f"\n  {c(DIM,'No peers visible yet. Waiting for field heartbeats...')}\n")
            else:
                print(f"\n  {c(PUR, str(len(peers))+' nodes in the field:')}\n")
                for p in peers:
                    entry = p['entry'] or ''
                    lang  = entry.split('.')[-1] if '.' in entry else 'exec'
                    print(f"  {c(GRN,'◉')}  {c(WHT+BOLD, p['name']):<18} {c(DIM, entry)}  {c(CYAN, p['addr'] or '')}")
                    if p['tags']:
                        print(f"     {c(DIM, '  '.join(p['tags'][:6]))}")
                print()

        # ── refresh ────────────────────────────────────────────────────────
        elif cmd == "refresh":
            field.refresh()
            s2 = field.folder.summary()
            print(f"  {c(GRN,'✓')} Re-scanned. Tags: {', '.join(list(s2['tags'].keys())[:6])}")

        # ── scan ───────────────────────────────────────────────────────────
        elif cmd == "scan":
            cmd_scan(arg or str(field.folder.path))

        # ── help ───────────────────────────────────────────────────────────
        elif cmd in ("help", "h", "?"):
            print(f"""
  {c(PUR,'Commands')}

  {c(WHT,'seek')} <query>       Find nodes that resonate with your query
  {c(WHT,'ls')}                 List files in your own node
  {c(WHT,'ls')} <name>          List info about another node
  {c(WHT,'open')}               Run your own node's entry point
  {c(WHT,'open')} <name>        Run another node's entry point (if local)
  {c(WHT,'who')}                See all nodes in the field
  {c(WHT,'scan')} [path]        Re-scan a folder's aura
  {c(WHT,'refresh')}            Re-scan your own folder
  {c(WHT,'help')}               This help
  {c(WHT,'quit')}               Leave the field
""")
        elif cmd in ("quit", "q", "exit"):
            break
        else:
            print(f"  {c(DIM,'Unknown command. Type help.')}")

    field.leave()


# ── Main ──────────────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h","--help","help"):
        print(BANNER)
        print(__doc__)
        return

    cmd = args[0].lower()

    # ── scan ───────────────────────────────────────────────────────────────
    if cmd == "scan":
        folder = args[1] if len(args) > 1 else "."
        cmd_scan(folder)

    # ── new ────────────────────────────────────────────────────────────────
    elif cmd == "new":
        if len(args) < 2:
            print(f"  {RED}Usage: aura new <folder> [lang]{R}"); return
        lang = args[2] if len(args) > 2 else "py"
        cmd_new(args[1], lang)

    # ── mount ──────────────────────────────────────────────────────────────
    elif cmd == "mount":
        if len(args) < 2:
            print(f"  {RED}Usage: aura mount <folder>{R}"); return
        cmd_mount(args[1])

    # ── field ──────────────────────────────────────────────────────────────
    elif cmd == "field":
        path, name = load_mount()
        if not path:
            # default to cwd
            path = os.getcwd()
            print(f"  {YEL}No folder mounted. Using current dir: {path}{R}")
            print(f"  {DIM}Tip: run 'aura mount <folder>' first{R}\n")
        field = AuraField(path, name)
        field.join()
        time.sleep(0.4)
        _field_session(field)

    # ── seek (quick, no REPL) ──────────────────────────────────────────────
    elif cmd == "seek":
        query = " ".join(args[1:])
        if not query:
            print(f"  {RED}Usage: aura seek <query>{R}"); return
        path, name = load_mount()
        if not path:
            path = os.getcwd()
        field = AuraField(path, name)
        field.join()
        time.sleep(0.3)
        print(f"\n  {c(YEL,'◎')} Seeking '{query}'...\n")
        results = field.seek(query)
        time.sleep(1.5)
        results = field.seek(query)
        if not results:
            print(f"  {c(DIM,'No resonance found.')}")
        else:
            for r in results:
                print(f"  {bar(r['score'])}  {c(WHT+BOLD, r['name']):<16}  {', '.join(r['tags'][:5])}")
        print()
        field.leave()

    # ── watch ──────────────────────────────────────────────────────────────
    elif cmd == "watch":
        path, name = load_mount()
        if not path: path = os.getcwd()
        field = AuraField(path, name)
        field.join()
        print(f"\n  {c(GRN,'◉')} Watching the field... {c(DIM,'Ctrl+C to stop')}\n")
        field.on_peer(lambda pid, nm, s:
            print(f"  {c(GRN,'◉')}  {c(WHT,nm):<16}  joined   {c(DIM,'  '.join(list(s.get('tags',{}).keys())[:5]))}")
        )
        field.on_seek(lambda pid, nm, q, sc:
            print(f"  {c(YEL,'◎')}  {c(WHT,nm):<16}  seeks    {c(YEL, q)}")
        )
        try:
            while True: time.sleep(1)
        except KeyboardInterrupt:
            pass
        field.leave()

    else:
        print(f"  {RED}Unknown command: {cmd}{R}")
        print(f"  Run 'aura help' for usage.")


if __name__ == "__main__":
    main()
