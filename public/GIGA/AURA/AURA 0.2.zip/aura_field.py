"""
AURA Field — peer-to-peer folder sharing protocol.

Each node announces its folder aura over multicast.
No server. No index. No addresses.
When you seek, the field resonates back the folders that match.
"""

import os
import json
import socket
import struct
import time
import threading
import uuid
from pathlib import Path
from aura_folder import FolderAura

# ── Protocol constants ────────────────────────────────────────────────────
FIELD_GROUP   = "239.77.77.77"
FIELD_PORT    = 7777
FIELD_MAGIC   = b"\xA0\x52"      # AuRa
PROTO_VERSION = 1

MSG_ANNOUNCE  = 0x01    # "my folder exists, here is its aura"
MSG_SEEK      = 0x02    # "I am looking for X"
MSG_RESONATE  = 0x03    # "my folder matches your seek"
MSG_FETCH     = 0x04    # "send me the file listing of your folder"
MSG_LISTING   = 0x05    # "here is my folder listing"
MSG_LEAVE     = 0x06    # "I'm going offline"


def _encode(msg_type: int, payload: dict) -> bytes:
    body   = json.dumps(payload, separators=(",",":")).encode()
    header = FIELD_MAGIC + bytes([PROTO_VERSION, msg_type])
    length = struct.pack("!H", len(body))
    return header + length + body

def _decode(data: bytes):
    if len(data) < 6 or data[:2] != FIELD_MAGIC:
        return None
    msg_type = data[3]
    length   = struct.unpack("!H", data[4:6])[0]
    try:
        return msg_type, json.loads(data[6:6+length].decode())
    except Exception:
        return None


class AuraField:
    """
    The network layer of AURA.
    Manages one local folder node + awareness of remote nodes.
    """

    def __init__(self, folder_path: str, name: str | None = None):
        self.node_id  = str(uuid.uuid4())[:8]
        self.folder   = FolderAura(folder_path).scan()
        self.name     = name or self.folder.meta.get("name", Path(folder_path).name)

        # remote peers: node_id → {name, summary, addr, last_seen}
        self.peers: dict[str, dict] = {}
        self._lock    = threading.Lock()
        self._running = False
        self._tx      = None
        self._rx      = None

        # callbacks
        self._on_peer:    list = []
        self._on_seek:    list = []
        self._on_resonate: list = []

    # ── lifecycle ─────────────────────────────────────────────────────────

    def join(self):
        self._setup_sockets()
        self._running = True
        threading.Thread(target=self._rx_loop,        daemon=True, name="aura-rx").start()
        threading.Thread(target=self._announce_loop,  daemon=True, name="aura-tx").start()
        threading.Thread(target=self._watch_loop,     daemon=True, name="aura-watch").start()

    def leave(self):
        if self._running:
            self._send(MSG_LEAVE, {"node_id": self.node_id, "name": self.name})
            self._running = False
        try: self._tx.close()
        except: pass
        try: self._rx.close()
        except: pass

    # ── actions ───────────────────────────────────────────────────────────

    def seek(self, query: str) -> list[dict]:
        """
        Broadcast a seek. Score all known peers locally.
        Returns matches sorted by resonance.
        """
        self._send(MSG_SEEK, {
            "node_id": self.node_id,
            "name":    self.name,
            "query":   query,
            "ts":      time.time(),
        })

        matches = []
        with self._lock:
            for pid, peer in self.peers.items():
                tags = peer.get("summary", {}).get("tags", {})
                # build a temporary FolderAura just for scoring
                fa = FolderAura.__new__(FolderAura)
                fa.tags  = tags
                fa.files = []
                fa.meta  = {}
                fa.entry = None
                fa.path  = Path(peer.get("summary", {}).get("path", "/"))
                score = fa.resonate(query)
                if score > 0.05:
                    matches.append({
                        "node_id":     pid,
                        "name":        peer.get("name"),
                        "score":       round(score, 3),
                        "addr":        peer.get("addr"),
                        "summary":     peer.get("summary", {}),
                        "description": peer.get("summary", {}).get("description", ""),
                        "tags":        list(tags.keys())[:8],
                        "entry":       peer.get("summary", {}).get("entry"),
                    })

        matches.sort(key=lambda x: -x["score"])
        return matches

    def refresh(self):
        """Re-scan this node's folder and re-announce."""
        self.folder = FolderAura(str(self.folder.path)).scan()

    def on_peer(self, fn):      self._on_peer.append(fn)
    def on_seek(self, fn):      self._on_seek.append(fn)
    def on_resonate(self, fn):  self._on_resonate.append(fn)

    def peers_list(self) -> list[dict]:
        with self._lock:
            return [
                {
                    "node_id":  pid,
                    "name":     p.get("name"),
                    "tags":     list(p.get("summary",{}).get("tags",{}).keys())[:6],
                    "files":    p.get("summary",{}).get("file_count", 0),
                    "entry":    p.get("summary",{}).get("entry"),
                    "addr":     p.get("addr"),
                    "last_seen":p.get("last_seen", 0),
                }
                for pid, p in self.peers.items()
            ]

    # ── internal networking ───────────────────────────────────────────────

    def _setup_sockets(self):
        self._tx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._tx.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 8)
        self._tx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self._rx = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._rx.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._rx.bind(("", FIELD_PORT))
        mreq = struct.pack("4sL", socket.inet_aton(FIELD_GROUP), socket.INADDR_ANY)
        self._rx.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        self._rx.settimeout(1.0)

    def _send(self, msg_type: int, payload: dict):
        try:
            pkt = _encode(msg_type, payload)
            self._tx.sendto(pkt, (FIELD_GROUP, FIELD_PORT))
        except Exception:
            pass

    def _announce(self):
        summary = self.folder.summary()
        self._send(MSG_ANNOUNCE, {
            "node_id": self.node_id,
            "name":    self.name,
            "summary": summary,
            "ts":      time.time(),
        })

    def _announce_loop(self):
        self._announce()
        while self._running:
            time.sleep(15)
            self._announce()

    def _rx_loop(self):
        while self._running:
            try:
                data, addr = self._rx.recvfrom(65535)
                decoded = _decode(data)
                if decoded is None:
                    continue
                msg_type, payload = decoded
                if payload.get("node_id") == self.node_id:
                    continue
                self._handle(msg_type, payload, addr[0])
            except socket.timeout:
                continue
            except Exception:
                continue

    def _handle(self, msg_type: int, payload: dict, addr: str):
        pid  = payload.get("node_id")
        name = payload.get("name", "?")

        if msg_type == MSG_ANNOUNCE:
            with self._lock:
                self.peers[pid] = {
                    "name":      name,
                    "summary":   payload.get("summary", {}),
                    "addr":      addr,
                    "last_seen": time.time(),
                }
            for fn in self._on_peer:
                fn(pid, name, payload.get("summary", {}))

        elif msg_type == MSG_SEEK:
            query = payload.get("query", "")
            score = self.folder.resonate(query)
            if score > 0.05:
                self._send(MSG_RESONATE, {
                    "node_id":  self.node_id,
                    "name":     self.name,
                    "for_node": pid,
                    "score":    round(score, 3),
                    "summary":  self.folder.summary(),
                })
            for fn in self._on_seek:
                fn(pid, name, query, score)

        elif msg_type == MSG_RESONATE:
            for fn in self._on_resonate:
                fn(pid, name, payload.get("score", 0), payload.get("summary", {}))
            # update peers with resonance info
            with self._lock:
                if pid not in self.peers:
                    self.peers[pid] = {}
                self.peers[pid].update({
                    "name":      name,
                    "summary":   payload.get("summary", {}),
                    "addr":      payload.get("addr", ""),
                    "last_seen": time.time(),
                })

        elif msg_type == MSG_LEAVE:
            with self._lock:
                self.peers.pop(pid, None)

    def _watch_loop(self):
        """Re-scan folder every 30s — if it changed, re-announce."""
        last_fp = self.folder.fingerprint()
        while self._running:
            time.sleep(30)
            try:
                self.folder = FolderAura(str(self.folder.path)).scan()
                fp = self.folder.fingerprint()
                if fp != last_fp:
                    last_fp = fp
                    self._announce()
            except Exception:
                pass
