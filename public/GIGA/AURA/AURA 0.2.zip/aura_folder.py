"""
AURA — A folder IS a node.

The folder structure replaces URLs and addresses.
Files inside are the content.
The ENTRY POINT file (aura.py / aura.sh / aura.js / aura.any)
  is executed when someone visits your node.
The folder's contents are automatically indexed as your aura.
No HTML. No server. Any language.

Folder structure (your "site"):
  ~/my_node/
    aura.py          ← entry point (any language)
    aura.meta        ← human-readable metadata (optional)
    data/            ← your files, shared automatically
    lib/             ← your code
    assets/          ← anything

When someone seeks "music production", AURA scans the field,
finds your folder, reads what's in it, scores it, and if it
resonates — executes your entry point in a sandbox.
"""

import os
import json
import time
import hashlib
import subprocess
import threading
import mimetypes
from pathlib import Path
from collections import defaultdict


# ── Entry point detection ──────────────────────────────────────────────────
# Any of these filenames can be the "front door" of a node folder.
# Executed when a visitor arrives. Any language — AURA figures it out.

ENTRY_POINTS = [
    "aura.py",   "aura.sh",   "aura.js",   "aura.rb",
    "aura.go",   "aura.rs",   "aura.lua",  "aura.pl",
    "aura.php",  "aura.r",    "aura.jl",   "aura.hs",
    "aura.ex",   "aura.cs",   "aura.java", "aura.c",
    "aura.cpp",  "main.py",   "main.sh",   "index.py",
    "run",       "start",     "launch",
]

RUNNERS = {
    ".py":   ["python3"],
    ".sh":   ["bash"],
    ".js":   ["node"],
    ".rb":   ["ruby"],
    ".lua":  ["lua"],
    ".pl":   ["perl"],
    ".php":  ["php"],
    ".r":    ["Rscript"],
    ".jl":   ["julia"],
    ".ex":   ["elixir"],
    "":      [],   # executable — run directly
}

# ── Folder Aura Scanner ────────────────────────────────────────────────────

class FolderAura:
    """
    Reads a folder and builds a semantic aura from its contents.
    No manual tagging. The folder speaks for itself.
    """

    def __init__(self, path: str):
        self.path   = Path(path).expanduser().resolve()
        self.tags:  dict[str, float] = {}
        self.files: list[dict] = []
        self.meta:  dict = {}
        self.entry: Path | None = None

    def scan(self) -> "FolderAura":
        """Walk the folder, build the aura."""
        if not self.path.exists():
            raise FileNotFoundError(f"Node folder not found: {self.path}")

        self._load_meta()
        self._find_entry()
        self._walk(self.path, depth=0)
        self._normalize()
        return self

    def _load_meta(self):
        """aura.meta file: human hints to shape the aura."""
        meta_path = self.path / "aura.meta"
        if meta_path.exists():
            try:
                for line in meta_path.read_text().splitlines():
                    line = line.strip()
                    if ":" in line:
                        k, v = line.split(":", 1)
                        self.meta[k.strip().lower()] = v.strip()
                # meta tags carry highest weight
                for tag in self.meta.get("tags", "").split(","):
                    tag = tag.strip().lower()
                    if tag:
                        self.tags[tag] = self.tags.get(tag, 0.0) + 1.0
                # name, description feed into tags too
                for field in ("name", "description", "about"):
                    for word in self.meta.get(field, "").lower().split():
                        if len(word) > 3:
                            self.tags[word] = self.tags.get(word, 0.0) + 0.3
            except Exception:
                pass

    def _find_entry(self):
        for name in ENTRY_POINTS:
            candidate = self.path / name
            if candidate.exists():
                self.entry = candidate
                return

    def _walk(self, folder: Path, depth: int):
        if depth > 4:
            return
        try:
            items = list(folder.iterdir())
        except PermissionError:
            return

        for item in items:
            if item.name.startswith(".") or item.name == "__pycache__":
                continue

            if item.is_dir():
                # directory names are strong semantic signals
                name = item.name.lower().replace("_", " ").replace("-", " ")
                for word in name.split():
                    if len(word) > 2:
                        self.tags[word] = self.tags.get(word, 0.0) + 0.4
                self._walk(item, depth + 1)

            elif item.is_file():
                self._absorb_file(item)

    def _absorb_file(self, p: Path):
        stat = p.stat()
        ext  = p.suffix.lower()

        record = {
            "name":     p.name,
            "path":     str(p.relative_to(self.path)),
            "size":     stat.st_size,
            "ext":      ext,
            "modified": stat.st_mtime,
        }
        self.files.append(record)

        # filename words → tags
        stem = p.stem.lower().replace("_", " ").replace("-", " ")
        for word in stem.split():
            if len(word) > 2:
                self.tags[word] = self.tags.get(word, 0.0) + 0.25

        # extension → semantic category
        ext_semantics = {
            ".py":    ["python", "code", "programming"],
            ".js":    ["javascript", "code", "web", "frontend"],
            ".ts":    ["typescript", "code", "frontend"],
            ".rs":    ["rust", "code", "systems"],
            ".go":    ["golang", "code", "systems"],
            ".cpp":   ["c++", "code", "systems"],
            ".c":     ["c", "code", "systems"],
            ".sh":    ["shell", "code", "sysadmin"],
            ".md":    ["writing", "docs", "markdown"],
            ".txt":   ["writing", "text"],
            ".pdf":   ["document", "pdf"],
            ".png":   ["image", "visual", "design"],
            ".jpg":   ["image", "photo", "visual"],
            ".svg":   ["vector", "design", "visual"],
            ".mp3":   ["audio", "music", "sound"],
            ".wav":   ["audio", "music", "sound"],
            ".flac":  ["audio", "music", "sound"],
            ".mp4":   ["video"],
            ".blend": ["3d", "blender", "visual"],
            ".csv":   ["data", "spreadsheet", "analysis"],
            ".json":  ["data", "code", "config"],
            ".sql":   ["database", "data", "sql"],
            ".html":  ["web", "html", "frontend"],
            ".css":   ["design", "web", "style"],
            ".ipynb": ["notebook", "python", "data", "science"],
            ".r":     ["r", "statistics", "data", "science"],
            ".jl":    ["julia", "science", "math"],
        }
        for tag in ext_semantics.get(ext, [ext.lstrip(".") if ext else "file"]):
            self.tags[tag] = self.tags.get(tag, 0.0) + 0.2

        # peek inside small text files for keywords
        if ext in (".py",".js",".ts",".md",".txt",".sh",".rs",".go",".cpp",".c",".r",".jl"):
            if stat.st_size < 50_000:
                try:
                    content = p.read_text(errors="ignore")[:3000]
                    self._extract_keywords(content)
                except Exception:
                    pass

    def _extract_keywords(self, text: str):
        stopwords = {
            "the","and","for","not","with","this","that","from","are","was",
            "has","have","been","will","its","can","but","you","def","import",
            "return","class","self","true","false","none","elif","else","pass",
            "print","open","file","path","str","int","list","dict","type",
        }
        words = text.lower().replace("\n", " ").split()
        freq: dict[str, int] = defaultdict(int)
        for w in words:
            w = "".join(c for c in w if c.isalpha())
            if len(w) > 4 and w not in stopwords:
                freq[w] += 1
        for word, count in sorted(freq.items(), key=lambda x: -x[1])[:20]:
            weight = min(0.4, count * 0.04)
            self.tags[word] = self.tags.get(word, 0.0) + weight

    def _normalize(self):
        if not self.tags:
            return
        mx = max(self.tags.values())
        if mx > 0:
            self.tags = {k: v / mx for k, v in self.tags.items()}

    def resonate(self, query: str) -> float:
        """Score: how well does this folder match the query?"""
        words = [w.lower().strip() for w in query.split() if len(w) > 1]
        if not words:
            return 0.0
        total = 0.0
        for w in words:
            if w in self.tags:
                total += self.tags[w]
            else:
                for tag, weight in self.tags.items():
                    if w in tag or tag in w:
                        total += weight * 0.5
                        break
        return min(1.0, total / max(1, len(words)))

    def fingerprint(self) -> str:
        """Stable hash of folder contents — changes when files change."""
        h = hashlib.sha256()
        for f in sorted(self.files, key=lambda x: x["path"]):
            h.update(f["path"].encode())
            h.update(str(f["modified"]).encode())
        return h.hexdigest()[:12]

    def summary(self) -> dict:
        top_tags = sorted(self.tags.items(), key=lambda x: -x[1])[:12]
        return {
            "name":        self.meta.get("name", self.path.name),
            "path":        str(self.path),
            "description": self.meta.get("description", ""),
            "tags":        dict(top_tags),
            "file_count":  len(self.files),
            "entry":       str(self.entry.name) if self.entry else None,
            "fingerprint": self.fingerprint(),
        }

    def run_entry(self, args: list[str] = None, env: dict = None) -> subprocess.Popen | None:
        """
        Execute the folder's entry point.
        Any language — AURA figures out the runner.
        Returns the process (streaming output live).
        """
        if not self.entry:
            return None

        ext    = self.entry.suffix.lower()
        runner = RUNNERS.get(ext)
        if runner is None:
            # try executable directly
            if os.access(self.entry, os.X_OK):
                runner = []
            else:
                return None

        cmd = runner + [str(self.entry)] + (args or [])
        merged_env = {**os.environ, **(env or {}), "AURA_NODE": str(self.path)}

        return subprocess.Popen(
            cmd,
            cwd=str(self.path),
            env=merged_env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
        )
