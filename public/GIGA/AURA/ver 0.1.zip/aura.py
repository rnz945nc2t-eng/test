#!/usr/bin/env python3
"""
AURA CLI — the terminal interface to the AURA field.

Usage:
  aura join <name> [--tags tag1,tag2,...]
  aura seek <query>
  aura share <path> [description]
  aura say <text>
  aura who                    # who is in the field right now
  aura status                 # your aura
  aura watch                  # live field monitor
  aura field                  # start interactive REPL
"""

import sys
import os
import time
import json
import threading
import signal

# add parent dir
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from aura_node import AuraNode, AURA_MULTICAST_GROUP, AURA_PORT

# ── Terminal colors (no dependencies) ──────────────────────────────────────

ESC = "\033["
RESET  = f"{ESC}0m"
BOLD   = f"{ESC}1m"
DIM    = f"{ESC}2m"
PURPLE = f"{ESC}35m"
CYAN   = f"{ESC}36m"
GREEN  = f"{ESC}32m"
YELLOW = f"{ESC}33m"
BLUE   = f"{ESC}34m"
PINK   = f"{ESC}95m"
WHITE  = f"{ESC}97m"
RED    = f"{ESC}31m"
CLEAR  = "\033[2J\033[H"

def c(color, text): return f"{color}{text}{RESET}"
def bar(score, width=16):
    filled = int(score * width)
    return c(PURPLE, "█" * filled) + c(DIM, "░" * (width - filled))


BANNER = f"""
{PURPLE}  ╔═══════════════════════════════════════╗
  ║  {WHITE}A U R A{PURPLE}  ·  field protocol v0.1.0   ║
  ║  {DIM}Autonomous Universal Resonance Arch.{PURPLE}  ║
  ╚═══════════════════════════════════════╝{RESET}
  {DIM}No addresses · No indexing · Just resonance{RESET}
"""


# ── State file — persist identity across sessions ─────────────────────────

STATE_FILE = os.path.expanduser("~/.aura_session.json")

def save_session(name: str, tags: list):
    with open(STATE_FILE, "w") as f:
        json.dump({"name": name, "tags": tags}, f)

def load_session() -> tuple[str, list] | None:
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE) as f:
                d = json.load(f)
            return d["name"], d.get("tags", [])
        except Exception:
            pass
    return None


# ── REPL / watch mode ─────────────────────────────────────────────────────

def print_field_event(kind, name, detail, score=None):
    ts = time.strftime("%H:%M:%S")
    if kind == "peer":
        print(f"  {DIM}{ts}{RESET}  {GREEN}◉{RESET} {c(WHITE,name)} joined  {DIM}{detail}{RESET}")
    elif kind == "seek":
        print(f"  {DIM}{ts}{RESET}  {YELLOW}◎{RESET} {c(WHITE,name)} seeks: {c(YELLOW, detail)}")
    elif kind == "share":
        print(f"  {DIM}{ts}{RESET}  {CYAN}⬡{RESET} {c(WHITE,name)} shared: {c(CYAN, detail)}")


def run_repl(node: AuraNode):
    """Interactive AURA field REPL."""
    print(BANNER)
    print(f"  {GREEN}◉{RESET} You are {c(WHITE+BOLD, node.name)}  [{c(DIM, node.node_id)}]")
    print(f"  {DIM}Field: {AURA_MULTICAST_GROUP}:{AURA_PORT}{RESET}\n")
    print(f"  {DIM}Commands: seek <query> · share <path> · say <text> · who · aura · help · quit{RESET}\n")

    # register live callbacks
    def on_peer(pid, name, tags):
        tag_str = "  ".join(list(tags.keys())[:4])
        print(f"\n  {GREEN}→{RESET} {c(GREEN, name)} entered the field  {c(DIM, tag_str)}")
        print("  > ", end="", flush=True)

    def on_seek(pid, name, query, score):
        if score > 0.08:
            print(f"\n  {YELLOW}◎{RESET} {c(YELLOW, name)} seeks '{query}'  — you resonate {c(PURPLE, f'{score:.0%}')}")
            print("  > ", end="", flush=True)

    def on_share(pid, name, payload):
        item = payload.get("filename") or payload.get("text","")[:40]
        print(f"\n  {CYAN}⬡{RESET} {c(CYAN, name)} shared: {c(WHITE, item)}")
        print("  > ", end="", flush=True)

    node.on_peer(on_peer)
    node.on_seek(on_seek)
    node.on_share(on_share)

    while True:
        try:
            raw = input("  > ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not raw:
            continue

        parts = raw.split(None, 1)
        cmd   = parts[0].lower()
        arg   = parts[1] if len(parts) > 1 else ""

        # ── seek ──────────────────────────────────────────────────────────
        if cmd in ("seek", "s"):
            if not arg:
                print(f"  {DIM}Usage: seek <what you're looking for>{RESET}"); continue
            print(f"\n  {YELLOW}◎{RESET} Seeking '{arg}' in the field...\n")
            results = node.seek(arg)
            if not results:
                print(f"  {DIM}No resonance found yet. Field is listening...{RESET}")
            else:
                for r in results:
                    tags = "  ".join(r["tags"][:5])
                    nid = r['node_id']
                    print(f"  {bar(r['score'])}  {c(WHITE+BOLD, r['name'])}  {c(DIM, '['+nid+']')}")
                    print(f"  {'':20}{c(DIM, tags)}")
                    print()
            print()

        # ── share ─────────────────────────────────────────────────────────
        elif cmd in ("share", "sh"):
            if not arg:
                print(f"  {DIM}Usage: share <path> [description]{RESET}"); continue
            path_parts = arg.split(None, 1)
            path = path_parts[0]
            desc = path_parts[1] if len(path_parts) > 1 else ""
            node.share(path, desc)

        # ── say / broadcast text ─────────────────────────────────────────
        elif cmd in ("say", "broadcast", "b"):
            if not arg:
                print(f"  {DIM}Usage: say <text or idea>{RESET}"); continue
            node.broadcast_text(arg)
            print(f"  {CYAN}⬡{RESET} Broadcast into the field")

        # ── who ───────────────────────────────────────────────────────────
        elif cmd == "who":
            st = node.status()
            peers = st["peers"]
            if not peers:
                print(f"\n  {DIM}No peers visible yet. Waiting for heartbeats...{RESET}\n")
            else:
                print(f"\n  {c(PURPLE, f'{len(peers)} participants in field:')}\n")
                for p in peers:
                    tags = "  ".join(p["tags"][:5])
                    print(f"  {GREEN}◉{RESET}  {c(WHITE+BOLD, p['name'])}  {c(DIM, tags)}")
                print()

        # ── aura (your own status) ─────────────────────────────────────────
        elif cmd in ("aura", "me", "status"):
            st   = node.status()
            tags = st["aura_tags"]
            print(f"\n  {c(PURPLE+BOLD, 'Your Aura')}\n")
            if not tags:
                print(f"  {DIM}Your aura is still forming. Share files or seek things.{RESET}")
            else:
                for tag, weight in tags:
                    print(f"  {bar(weight, 12)}  {c(WHITE, tag):<20}  {c(DIM, f'{weight:.2f}')}")
            print(f"\n  {DIM}Peers: {st['peer_count']}  |  Field: {st['field']}{RESET}\n")

        # ── help ──────────────────────────────────────────────────────────
        elif cmd in ("help", "h", "?"):
            print(f"""
  {c(PURPLE, 'AURA commands')}

  {c(WHITE,'seek')} <query>        — find who resonates with your query
  {c(WHITE,'share')} <path>         — drop a file into the field (right-click equivalent)
  {c(WHITE,'say')} <text>           — broadcast text/idea into the field
  {c(WHITE,'who')}                  — see participants in the field
  {c(WHITE,'aura')}                 — see your own aura (what the field knows about you)
  {c(WHITE,'quit')}                 — leave the field gracefully
            """)

        # ── quit ──────────────────────────────────────────────────────────
        elif cmd in ("quit", "q", "exit", "bye"):
            print(f"\n  {DIM}Leaving the field...{RESET}")
            break

        else:
            print(f"  {DIM}Unknown command. Type 'help'.{RESET}")

    node.leave_field()


# ── Watch mode — passive field monitor ───────────────────────────────────

def run_watch(node: AuraNode):
    print(BANNER)
    print(f"  {DIM}Watching the field... Ctrl+C to stop.{RESET}\n")

    node.on_peer(lambda pid, name, tags:
        print(f"  {GREEN}◉  {c(WHITE,name):<16}{RESET}  joined   {c(DIM,'  '.join(list(tags.keys())[:5]))}")
    )
    node.on_seek(lambda pid, name, q, sc:
        print(f"  {YELLOW}◎  {c(WHITE,name):<16}{RESET}  seeks    {c(YELLOW, q)}")
    )
    node.on_share(lambda pid, name, p:
        print(f"  {CYAN}⬡  {c(WHITE,name):<16}{RESET}  shared   {c(CYAN, p.get('filename') or p.get('text','')[:40])}")
    )

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        pass
    finally:
        node.leave_field()


# ── Entry point ───────────────────────────────────────────────────────────

def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(BANNER)
        print(__doc__)
        return

    cmd = args[0].lower()

    # ── join — establish identity and enter the field ──────────────────
    if cmd == "join":
        if len(args) < 2:
            print(f"  {RED}Usage: aura join <name> [--tags tag1,tag2,...]{RESET}"); return

        name = args[1]
        tags = []
        if "--tags" in args:
            idx = args.index("--tags")
            if idx + 1 < len(args):
                tags = [t.strip() for t in args[idx+1].split(",")]

        save_session(name, tags)
        node = AuraNode(name, tags)
        node.join_field()
        run_repl(node)
        return

    # ── all other commands need a session ──────────────────────────────
    session = load_session()
    if session is None:
        print(f"\n  {RED}Not in the field yet. Run:  aura join <your-name>{RESET}\n")
        return

    name, tags = session
    node = AuraNode(name, tags)
    node.join_field()
    time.sleep(0.3)   # let first heartbeat go out

    if cmd == "seek":
        query = " ".join(args[1:])
        if not query:
            print(f"  {RED}Usage: aura seek <query>{RESET}"); node.leave_field(); return
        print(f"\n  {YELLOW}◎{RESET} Seeking '{query}'...\n")
        results = node.seek(query)
        time.sleep(1.5)   # wait for async resonance replies
        results = node.seek(query)  # re-score with fresh peer data
        if not results:
            print(f"  {DIM}No resonance found. Field may be empty or no one matches.{RESET}")
        else:
            for r in results:
                print(f"  {bar(r['score'])}  {c(WHITE+BOLD, r['name']):<14}  {c(DIM, '  '.join(r['tags'][:5]))}")
        print()

    elif cmd == "share":
        if len(args) < 2:
            print(f"  {RED}Usage: aura share <path>{RESET}"); node.leave_field(); return
        node.share(args[1], " ".join(args[2:]))

    elif cmd == "say":
        text = " ".join(args[1:])
        if not text:
            print(f"  {RED}Usage: aura say <text>{RESET}"); node.leave_field(); return
        node.broadcast_text(text)
        print(f"  {CYAN}⬡{RESET} '{text}' broadcast into the field")

    elif cmd == "who":
        time.sleep(2)   # collect heartbeats
        st = node.status()
        peers = st["peers"]
        if not peers:
            print(f"\n  {DIM}Field appears empty right now.{RESET}\n")
        else:
            print(f"\n  {c(PURPLE, str(len(peers)) + ' in the field:')}\n")
            for p in peers:
                print(f"  {GREEN}◉{RESET}  {c(WHITE+BOLD, p['name']):<16}  {c(DIM, '  '.join(p['tags'][:5]))}")
            print()

    elif cmd == "status":
        st   = node.status()
        tags = st["aura_tags"]
        aura_title = name + "'s Aura"
        print(f"\n  {c(PURPLE+BOLD, aura_title)}\n")
        if not tags:
            print(f"  {DIM}Aura forming... share files or seek to build it.{RESET}")
        else:
            for tag, w in tags:
                print(f"  {bar(w, 12)}  {c(WHITE, tag):<20}  {c(DIM, f'{w:.2f}')}")
        print()

    elif cmd == "watch":
        run_watch(node)
        return

    elif cmd == "field":
        run_repl(node)
        return

    else:
        print(f"  {RED}Unknown command: {cmd}{RESET}")

    node.leave_field()


if __name__ == "__main__":
    main()
