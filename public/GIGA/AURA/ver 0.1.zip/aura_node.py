"""
AURA - Autonomous Universal Resonance Architecture
Core node: identity, aura generation, self-indexing.
No addresses. No registration. You exist by resonating.
"""

import os
import json
import time
import hashlib
import socket
import struct
import threading
import uuid
import math
from pathlib import Path
from collections import defaultdict


AURA_MULTICAST_GROUP = "239.77.77.77"   # private multicast — the AURA field frequency
AURA_PORT            = 7777
AURA_VERSION         = "0.1.0"
AURA_MAGIC           = b"\xA0\x52"      # packet magic bytes: AuRa

MSG_HEARTBEAT  = 0x01   # "I exist, here is my aura"
MSG_SEEK       = 0x02   # "I am looking for resonance with X"
MSG_RESONANCE  = 0x03   # "I resonate with your seek"
MSG_SHARE      = 0x04   # "I am dropping this into the field"
MSG_FAREWELL   = 0x05   # "I am leaving the field"


# ---------------------------------------------------------------------------
# Aura: the semantic fingerprint of a participant
# ---------------------------------------------------------------------------

class Aura:
    """
    An Aura is automatically built from:
    - Files you share (names, extensions, content keywords)
    - Things you seek (what you look for)
    - Tags you declare
    - Activity patterns over time
    No manual indexing. The system learns you.
    """

    def __init__(self, node_id: str):
        self.node_id   = node_id
        self.tags: dict[str, float] = {}   # tag -> weight (0.0 - 1.0)
        self.history   = []                # recent activity
        self._lock     = threading.Lock()

    def absorb_file(self, path: str):
        """Learn from a shared file — name, extension, keywords."""
        p = Path(path)
        self._boost(p.stem.lower().replace("_", " ").replace("-", " "), 0.4)
        ext = p.suffix.lstrip(".").lower()
        if ext:
            # map extensions to semantic tags
            ext_map = {
                "py":"code python", "js":"code javascript", "ts":"code typescript",
                "rs":"code rust", "go":"code golang", "cpp":"code c++",
                "md":"writing docs", "txt":"writing text", "pdf":"document",
                "png":"image visual", "jpg":"image photo", "svg":"design vector",
                "mp3":"audio music", "wav":"audio sound", "flac":"audio music",
                "mp4":"video", "mov":"video", "blend":"3d blender",
                "csv":"data", "json":"data code", "sql":"data database",
                "sh":"code shell sysadmin", "dockerfile":"devops code",
            }
            for tag in ext_map.get(ext, ext).split():
                self._boost(tag, 0.3)

        # try reading text files for keywords
        if ext in ("py","js","ts","rs","go","md","txt","sh","csv","json"):
            try:
                with open(path, "r", errors="ignore") as f:
                    content = f.read(2048)
                self._extract_keywords(content)
            except Exception:
                pass

        self.history.append(("share", str(p.name), time.time()))

    def absorb_seek(self, query: str):
        """Learn from what you seek — reveals your interests."""
        words = [w.lower() for w in query.split() if len(w) > 2]
        for w in words:
            self._boost(w, 0.5)
        self.history.append(("seek", query, time.time()))

    def absorb_tags(self, tags: list[str]):
        """Explicit tags declared by the user — strong initial weight."""
        for t in tags:
            key = t.lower().strip()
            with self._lock:
                self.tags[key] = min(1.0, self.tags.get(key, 0.0) + 0.7)

    def _boost(self, tag: str, weight: float):
        with self._lock:
            self.tags[tag] = min(1.0, self.tags.get(tag, 0.0) + weight)

    def _extract_keywords(self, text: str):
        stopwords = {"the","and","for","not","with","this","that","from","are",
                     "was","has","have","been","will","its","can","but","you","def",
                     "import","return","class","self","true","false","none","elif"}
        words = text.lower().replace("\n"," ").split()
        freq: dict[str,int] = defaultdict(int)
        for w in words:
            w = "".join(c for c in w if c.isalpha())
            if len(w) > 3 and w not in stopwords:
                freq[w] += 1
        top = sorted(freq.items(), key=lambda x: -x[1])[:12]
        for word, count in top:
            self._boost(word, min(0.3, count * 0.05))

    def decay(self):
        """Called periodically — old tags fade, keeping the aura fresh."""
        with self._lock:
            self.tags = {k: v * 0.98 for k, v in self.tags.items() if v > 0.02}

    def resonate(self, query: str) -> float:
        """
        How well does this aura match the query?
        Returns a score 0.0 - 1.0.
        Pure semantic cosine-like matching — no index, no server.
        """
        words = [w.lower().strip() for w in query.split() if len(w) > 1]
        if not words:
            return 0.0
        total = 0.0
        with self._lock:
            for w in words:
                # exact match
                if w in self.tags:
                    total += self.tags[w]
                    continue
                # prefix / substring match (partial resonance)
                for tag, weight in self.tags.items():
                    if w in tag or tag in w:
                        total += weight * 0.6
                        break
        return min(1.0, total / max(1, len(words)))

    def top_tags(self, n=10) -> list[tuple[str, float]]:
        with self._lock:
            return sorted(self.tags.items(), key=lambda x: -x[1])[:n]

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "node_id": self.node_id,
                "tags": dict(sorted(self.tags.items(), key=lambda x: -x[1])[:20]),
                "timestamp": time.time(),
            }

    @classmethod
    def from_dict(cls, d: dict) -> "Aura":
        a = cls(d["node_id"])
        a.tags = d.get("tags", {})
        return a


# ---------------------------------------------------------------------------
# Packet codec — binary protocol over UDP multicast
# ---------------------------------------------------------------------------

MAGIC = b"\xA0\x52"   # 0xA0 0x52 = "AuRa"

def encode_packet(msg_type: int, payload: dict) -> bytes:
    body = json.dumps(payload, separators=(",",":")).encode()
    header = MAGIC + bytes([AURA_VERSION.count(".") + 1, msg_type])
    length = struct.pack("!H", len(body))
    return header + length + body

def decode_packet(data: bytes) -> tuple[int, dict] | None:
    if len(data) < 6 or data[:2] != MAGIC:
        return None
    msg_type = data[3]
    length   = struct.unpack("!H", data[4:6])[0]
    body     = data[6:6+length]
    try:
        return msg_type, json.loads(body.decode())
    except Exception:
        return None


# ---------------------------------------------------------------------------
# AuraNode — a participant in the field
# ---------------------------------------------------------------------------

class AuraNode:
    """
    One node in the AURA field.
    Runs two threads:
      - sender: broadcasts heartbeats + responds to seeks
      - listener: receives field traffic, builds a view of other nodes
    """

    def __init__(self, name: str, tags: list[str] | None = None):
        self.node_id  = str(uuid.uuid4())[:8]
        self.name     = name
        self.aura     = Aura(self.node_id)
        self.peers: dict[str, dict] = {}    # node_id -> {name, aura, last_seen}
        self._running = False
        self._sock_send = None
        self._sock_recv = None
        self._lock      = threading.Lock()
        self._seek_callbacks: list = []
        self._share_callbacks: list = []
        self._peer_callbacks: list  = []

        if tags:
            self.aura.absorb_tags(tags)

        # load persisted aura from disk
        self._aura_path = Path.home() / f".aura_{self.name.lower()}.json"
        self._load_aura()

    # ---- lifecycle --------------------------------------------------------

    def join_field(self):
        """Enter the AURA field. Start broadcasting your existence."""
        self._setup_sockets()
        self._running = True
        threading.Thread(target=self._listen_loop, daemon=True).start()
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()
        threading.Thread(target=self._decay_loop, daemon=True).start()
        print(f"\n  ◉ {self.name} [{self.node_id}] joined the AURA field")
        print(f"  ◎ Multicast: {AURA_MULTICAST_GROUP}:{AURA_PORT}  |  No address needed.\n")

    def leave_field(self):
        """Gracefully leave. Send farewell so peers clean up."""
        if self._running:
            self._broadcast(MSG_FAREWELL, {"node_id": self.node_id, "name": self.name})
            self._running = False
            self._save_aura()
        if self._sock_send:
            self._sock_send.close()
        if self._sock_recv:
            self._sock_recv.close()

    # ---- actions ----------------------------------------------------------

    def seek(self, query: str) -> list[dict]:
        """
        Broadcast a seek into the field.
        Returns locally known resonances immediately;
        remote nodes will also respond asynchronously.
        """
        self.aura.absorb_seek(query)
        payload = {
            "node_id": self.node_id,
            "name":    self.name,
            "query":   query,
            "ts":      time.time(),
        }
        self._broadcast(MSG_SEEK, payload)

        # score known peers immediately
        results = []
        with self._lock:
            for pid, peer in self.peers.items():
                peer_aura = Aura.from_dict({"node_id": pid, "tags": peer.get("tags", {})})
                score = peer_aura.resonate(query)
                if score > 0.05:
                    results.append({
                        "node_id": pid,
                        "name":    peer.get("name", "?"),
                        "score":   score,
                        "tags":    list(peer.get("tags", {}).keys())[:6],
                    })
        results.sort(key=lambda x: -x["score"])
        return results

    def share(self, path: str, description: str = ""):
        """
        Drop a file into the AURA field.
        No destination. The field absorbs it.
        Your aura learns from what you share.
        """
        p = Path(path)
        if not p.exists():
            print(f"  ✗ path not found: {path}")
            return

        self.aura.absorb_file(str(p))
        payload = {
            "node_id":     self.node_id,
            "name":        self.name,
            "filename":    p.name,
            "size":        p.stat().st_size,
            "description": description or p.stem,
            "aura_tags":   [t for t, _ in self.aura.top_tags(5)],
            "ts":          time.time(),
        }
        self._broadcast(MSG_SHARE, payload)
        print(f"  ⬡ Shared '{p.name}' into the field")
        self._save_aura()

    def broadcast_text(self, text: str):
        """Share raw text/idea into the field — no file needed."""
        words = text.lower().split()
        for w in words:
            if len(w) > 3:
                self.aura._boost(w, 0.3)
        payload = {
            "node_id":  self.node_id,
            "name":     self.name,
            "text":     text,
            "aura_tags": [t for t, _ in self.aura.top_tags(5)],
            "ts":       time.time(),
        }
        self._broadcast(MSG_SHARE, payload)

    # ---- callbacks --------------------------------------------------------

    def on_seek(self, fn):    self._seek_callbacks.append(fn)
    def on_share(self, fn):   self._share_callbacks.append(fn)
    def on_peer(self, fn):    self._peer_callbacks.append(fn)

    # ---- internal networking ---------------------------------------------

    def _setup_sockets(self):
        # multicast sender
        self._sock_send = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._sock_send.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
        self._sock_send.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        # multicast receiver
        self._sock_recv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        self._sock_recv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock_recv.bind(("", AURA_PORT))
        mreq = struct.pack("4sL", socket.inet_aton(AURA_MULTICAST_GROUP), socket.INADDR_ANY)
        self._sock_recv.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, mreq)
        self._sock_recv.settimeout(1.0)

    def _broadcast(self, msg_type: int, payload: dict):
        try:
            pkt = encode_packet(msg_type, payload)
            self._sock_send.sendto(pkt, (AURA_MULTICAST_GROUP, AURA_PORT))
        except Exception as e:
            pass   # field may not be reachable locally — that's ok

    def _listen_loop(self):
        while self._running:
            try:
                data, addr = self._sock_recv.recvfrom(65535)
                result = decode_packet(data)
                if result is None:
                    continue
                msg_type, payload = result
                # ignore our own packets
                if payload.get("node_id") == self.node_id:
                    continue
                self._handle_packet(msg_type, payload, addr)
            except socket.timeout:
                continue
            except Exception:
                continue

    def _handle_packet(self, msg_type: int, payload: dict, addr):
        pid  = payload.get("node_id")
        name = payload.get("name", "?")

        if msg_type == MSG_HEARTBEAT:
            with self._lock:
                self.peers[pid] = {
                    "name":      name,
                    "tags":      payload.get("tags", {}),
                    "last_seen": time.time(),
                    "addr":      addr[0],
                }
            for fn in self._peer_callbacks:
                fn(pid, name, payload.get("tags", {}))

        elif msg_type == MSG_SEEK:
            query = payload.get("query", "")
            score = self.aura.resonate(query)
            if score > 0.08:
                # respond with our resonance
                self._broadcast(MSG_RESONANCE, {
                    "node_id":    self.node_id,
                    "name":       self.name,
                    "seek_from":  pid,
                    "score":      round(score, 3),
                    "tags":       [t for t, _ in self.aura.top_tags(6)],
                    "ts":         time.time(),
                })
            for fn in self._seek_callbacks:
                fn(pid, name, query, score)

        elif msg_type == MSG_RESONANCE:
            for fn in self._seek_callbacks:
                fn(pid, name, f"[resonance to seek]", payload.get("score", 0))

        elif msg_type == MSG_SHARE:
            for fn in self._share_callbacks:
                fn(pid, name, payload)

        elif msg_type == MSG_FAREWELL:
            with self._lock:
                self.peers.pop(pid, None)

    def _heartbeat_loop(self):
        while self._running:
            payload = {
                "node_id": self.node_id,
                "name":    self.name,
                "tags":    dict(self.aura.top_tags(15)),
                "version": AURA_VERSION,
                "ts":      time.time(),
            }
            self._broadcast(MSG_HEARTBEAT, payload)
            time.sleep(10)   # heartbeat every 10s

    def _decay_loop(self):
        while self._running:
            self.aura.decay()
            # prune stale peers (no heartbeat in 60s)
            with self._lock:
                now = time.time()
                stale = [pid for pid, p in self.peers.items()
                         if now - p.get("last_seen", 0) > 60]
                for pid in stale:
                    del self.peers[pid]
            time.sleep(30)

    # ---- persistence ------------------------------------------------------

    def _save_aura(self):
        try:
            with open(self._aura_path, "w") as f:
                json.dump(self.aura.to_dict(), f, indent=2)
        except Exception:
            pass

    def _load_aura(self):
        try:
            if self._aura_path.exists():
                with open(self._aura_path) as f:
                    d = json.load(f)
                self.aura.tags = d.get("tags", {})
                print(f"  ◎ Aura loaded from disk ({len(self.aura.tags)} tags)")
        except Exception:
            pass

    # ---- info -------------------------------------------------------------

    def status(self) -> dict:
        with self._lock:
            peer_count = len(self.peers)
            peers = [
                {"name": v["name"], "tags": list(v.get("tags", {}).keys())[:4]}
                for v in self.peers.values()
            ]
        return {
            "node_id":    self.node_id,
            "name":       self.name,
            "aura_tags":  self.aura.top_tags(10),
            "peers":      peers,
            "peer_count": peer_count,
            "field":      f"{AURA_MULTICAST_GROUP}:{AURA_PORT}",
        }
