import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard"; // Keeping it imported just in case, or I can swap it
import Generator from "@/pages/Generator";

function Router() {
  return (
    <Switch>
      {/* Main route is now the Chat App (Generator) */}
      <Route path="/" component={Generator} />
      <Route path="/dashboard" component={Dashboard} /> 
      <Route path="/generator" component={Generator} />
      <Route path="/history" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
