# HST v4.1 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup; from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v4_1_hf', exist_ok=True)
os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2"); tokenizer.pad_token = tokenizer.eos_token

class EnhancedChunkProcessor(nn.Module):
    def __init__(self, d_model, chunk_size=16):
        super().__init__()
        self.chunk_size = chunk_size
        self.encoder = nn.TransformerEncoder(nn.TransformerEncoderLayer(d_model, 8, d_model*4, batch_first=True), num_layers=2)
        self.decoder = nn.TransformerDecoder(nn.TransformerDecoderLayer(d_model, 8, d_model*4, batch_first=True), num_layers=2)
    def forward(self, x):
        B, S, D = x.shape
        num_chunks = max(1, S // self.chunk_size)
        chunks = x[:, :num_chunks*self.chunk_size].view(B*num_chunks, self.chunk_size, D)
        encoded = self.encoder(chunks); decoded = self.decoder(encoded, encoded)
        return decoded.view(B, num_chunks*self.chunk_size, D)

class HSTv41HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.processor = EnhancedChunkProcessor(d_model, 16)
        self.lm_head = nn.Linear(d_model, vocab_size)
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        x = self.processor(x)
        return self.lm_head(x)


# ==================== Load Model ====================
tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv41HF().to(device); opt = torch.optim.Adam(model.parameters(), 1e-4); crit = nn.CrossEntropyLoss()
model.to(device)

try:
    model.load_state_dict(torch.load("/content/drive/MyDrive/HST_Training/v4_1_hf/hst_v4_1_hf.pt", map_location=device))
    print("✓ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit(1)

model.eval()

# ==================== Generate ====================
def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

print("\n" + "="*60)
print("TESTING TEXT GENERATION")
print("="*60 + "\n")

for prompt in ["The future of AI", "Machine learning enables", "Innovation starts with"]:
    print(f"Prompt: \"{prompt}\"")
    print(f"Generated:\n{generate_text(prompt, max_tokens=80)}\n")
