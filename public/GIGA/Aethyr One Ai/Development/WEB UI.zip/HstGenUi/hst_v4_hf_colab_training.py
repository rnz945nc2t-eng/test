# HST v4 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v4_hf', exist_ok=True)
print("HST v4 - HF Language Dataset Training")

os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

class ChunkEncoder(nn.Module):
    def __init__(self, d_model, chunk_size=16):
        super().__init__()
        self.chunk_size = chunk_size
        self.local_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model, 8, d_model*4, batch_first=True),
            num_layers=2
        )
    
    def forward(self, tokens):
        B, total_tokens, D = tokens.shape
        num_chunks = max(1, total_tokens // self.chunk_size)
        chunks = tokens[:, :num_chunks*self.chunk_size].view(B*num_chunks, self.chunk_size, D)
        encoded = self.local_encoder(chunks)
        return encoded.mean(dim=1).view(B, num_chunks, D)

class ChunkDecoder(nn.Module):
    def __init__(self, d_model, chunk_size=16, vocab_size=50257):
        super().__init__()
        self.chunk_size = chunk_size
        self.chunk_expander = nn.Linear(d_model, d_model*chunk_size)
        self.local_decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(d_model, 8, d_model*4, batch_first=True),
            num_layers=2
        )
        self.lm_head = nn.Linear(d_model, vocab_size)
    
    def forward(self, chunk_embeddings):
        B, num_chunks, D = chunk_embeddings.shape
        expanded = self.chunk_expander(chunk_embeddings).view(B*num_chunks, self.chunk_size, D)
        refined = self.local_decoder(expanded, expanded)
        return self.lm_head(refined.view(B, num_chunks*self.chunk_size, D))

class HSTv4HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256, chunk_size=16):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.chunk_encoder = ChunkEncoder(d_model, chunk_size)
        self.chunk_decoder = ChunkDecoder(d_model, chunk_size, vocab_size)
    
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        chunk_embs = self.chunk_encoder(x)
        return self.chunk_decoder(chunk_embs)

dataset = load_dataset("wikitext", "wikitext-2-v1", split="train[:10%]")
def tokenize_function(examples):
    return tokenizer(examples["text"], max_length=256, truncation=True, padding='max_length', return_tensors='pt')
tokenized = dataset.map(tokenize_function, batched=True, remove_columns=["text"])
tokenized.set_format('torch', columns=['input_ids'])

model = HSTv4HF(vocab_size=50257, d_model=256).to(device)
opt = torch.optim.Adam(model.parameters(), 1e-4)
crit = nn.CrossEntropyLoss()
scheduler = get_linear_schedule_with_warmup(opt, 100, 600)

for e in range(3):
    for i in range(0, min(200, len(tokenized)), 8):
        batch_ids = torch.stack([tokenized[j]['input_ids'] for j in range(i, min(i+8, len(tokenized)))]).to(device)
        opt.zero_grad()
        logits = model(batch_ids)
        loss = crit(logits[:, :-1].reshape(-1, 50257), batch_ids[:, 1:].reshape(-1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        scheduler.step()
        if i % 50 == 0: print(f"Epoch {e+1}, Step {i//8}: Loss {loss.item():.4f}")

torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v4_hf/hst_v4_hf.pt')
print("✓ HST v4 HF trained and saved")
