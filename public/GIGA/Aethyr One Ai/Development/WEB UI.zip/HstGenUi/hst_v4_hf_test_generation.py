# HST v4 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v4_hf', exist_ok=True)
print("HST v4 - HF Language Dataset Training")

os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

class ChunkEncoder(nn.Module):
    def __init__(self, d_model, chunk_size=16):
        super().__init__()
        self.chunk_size = chunk_size
        self.local_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model, 8, d_model*4, batch_first=True),
            num_layers=2
        )
    
    def forward(self, tokens):
        B, total_tokens, D = tokens.shape
        num_chunks = max(1, total_tokens // self.chunk_size)
        chunks = tokens[:, :num_chunks*self.chunk_size].view(B*num_chunks, self.chunk_size, D)
        encoded = self.local_encoder(chunks)
        return encoded.mean(dim=1).view(B, num_chunks, D)

class ChunkDecoder(nn.Module):
    def __init__(self, d_model, chunk_size=16, vocab_size=50257):
        super().__init__()
        self.chunk_size = chunk_size
        self.chunk_expander = nn.Linear(d_model, d_model*chunk_size)
        self.local_decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(d_model, 8, d_model*4, batch_first=True),
            num_layers=2
        )
        self.lm_head = nn.Linear(d_model, vocab_size)
    
    def forward(self, chunk_embeddings):
        B, num_chunks, D = chunk_embeddings.shape
        expanded = self.chunk_expander(chunk_embeddings).view(B*num_chunks, self.chunk_size, D)
        refined = self.local_decoder(expanded, expanded)
        return self.lm_head(refined.view(B, num_chunks*self.chunk_size, D))

class HSTv4HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256, chunk_size=16):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.chunk_encoder = ChunkEncoder(d_model, chunk_size)
        self.chunk_decoder = ChunkDecoder(d_model, chunk_size, vocab_size)
    
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        chunk_embs = self.chunk_encoder(x)
        return self.chunk_decoder(chunk_embs)


# ==================== Load Model ====================
tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv4HF(vocab_size=50257, d_model=256).to(device)
model.to(device)

try:
    model.load_state_dict(torch.load("/content/drive/MyDrive/HST_Training/v4_hf/hst_v4_hf.pt", map_location=device))
    print("✓ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit(1)

model.eval()

# ==================== Generate ====================
def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

print("\n" + "="*60)
print("TESTING TEXT GENERATION")
print("="*60 + "\n")

for prompt in ["The future of AI", "Machine learning enables", "Innovation starts with"]:
    print(f"Prompt: \"{prompt}\"")
    print(f"Generated:\n{generate_text(prompt, max_tokens=80)}\n")
