# HST v5.2 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup; from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v5_2_hf', exist_ok=True)
os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2"); tokenizer.pad_token = tokenizer.eos_token
print("HST v5.2 - HF Language Dataset Training")

class RecursiveDescentLatticeAnalyzer(nn.Module):
    def __init__(self, d_model, depth=4):
        super().__init__()
        self.layers = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(depth)])
        self.norms = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(depth)])
    def forward(self, x):
        for layer, norm in zip(self.layers, self.norms):
            x = norm(nn.functional.relu(layer(x)) + x)
        return x

class RecursiveHorizonPredictor(nn.Module):
    def __init__(self, d_model, horizons=4):
        super().__init__()
        self.horizon_predictors = nn.ModuleList([nn.Sequential(nn.Linear(d_model, d_model), nn.ReLU(), nn.Linear(d_model, d_model)) for _ in range(horizons)])
        self.aggregator = nn.Linear(d_model * horizons, d_model)
    def forward(self, x):
        predictions = [pred(x) for pred in self.horizon_predictors]
        combined = torch.cat(predictions, dim=-1)
        return self.aggregator(combined)

class HSTv52HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.analyzers = nn.ModuleList([RecursiveDescentLatticeAnalyzer(d_model) for _ in range(4)])
        self.horizon = RecursiveHorizonPredictor(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size)
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        for analyzer in self.analyzers: x = analyzer(x)
        x = self.horizon(x)
        return self.lm_head(x)

dataset = load_dataset("wikitext", "wikitext-2-v1", split="train[:10%]")
def tokenize_function(examples):
    return tokenizer(examples["text"], max_length=256, truncation=True, padding='max_length', return_tensors='pt')
tokenized = dataset.map(tokenize_function, batched=True, remove_columns=["text"])
tokenized.set_format('torch', columns=['input_ids'])

model = HSTv52HF().to(device); opt = torch.optim.Adam(model.parameters(), 1e-4); crit = nn.CrossEntropyLoss()
scheduler = get_linear_schedule_with_warmup(opt, 100, 600)
for e in range(3):
    for i in range(0, min(200, len(tokenized)), 8):
        batch_ids = torch.stack([tokenized[j]['input_ids'] for j in range(i, min(i+8, len(tokenized)))]).to(device)
        opt.zero_grad(); logits = model(batch_ids); loss = crit(logits[:, :-1].reshape(-1, 50257), batch_ids[:, 1:].reshape(-1))
        loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); scheduler.step()
        if i % 50 == 0: print(f"Epoch {e+1}, Step {i//8}: Loss {loss.item():.4f}")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v5_2_hf/hst_v5_2_hf.pt')
print("✓ HST v5.2 HF trained")
