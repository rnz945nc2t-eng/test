# HST v5 - Core Unified Architecture
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn; subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "torch"])
import numpy as np; from sklearn.preprocessing import StandardScaler; from torch.utils.data import DataLoader, TensorDataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v5_models', exist_ok=True)
print("HST v5 - Core Unified")

class LatticeCore(nn.Module):
    def __init__(self, d_model): super().__init__()
    self.transform = nn.Linear(d_model, d_model); self.weight = nn.Linear(d_model, 1); self.norm = nn.LayerNorm(d_model)
    def forward(self, x): t = self.transform(x); w = torch.softmax(self.weight(t), dim=1); return self.norm(t * w + x)

class HSTv5(nn.Module):
    def __init__(self, d_model=32, num_layers=4): 
        super().__init__()
        self.input = nn.Linear(1, d_model)
        self.cores = nn.ModuleList([LatticeCore(d_model) for _ in range(num_layers)])
        self.output = nn.Linear(d_model, 1)
    def forward(self, x):
        x = self.input(x.unsqueeze(-1) if len(x.shape)==2 else x)
        for core in self.cores: x = core(x)
        return self.output(x)

data = np.array([np.linspace(0, 5, 100) + 2*np.sin(2*np.pi*np.arange(100)/50) + np.random.normal(0, 0.5, 100) for _ in range(1000)])
scaler = StandardScaler(); data = scaler.fit_transform(data.reshape(-1, 1)).reshape(data.shape)
train_loader = DataLoader(TensorDataset(torch.FloatTensor(data[:800]).to(device)), batch_size=32, shuffle=True)
val_loader = DataLoader(TensorDataset(torch.FloatTensor(data[800:]).to(device)), batch_size=32)
model = HSTv5().to(device); opt = torch.optim.Adam(model.parameters(), 1e-3); crit = nn.MSELoss()
for e in range(10):
    for X, in train_loader: opt.zero_grad(); loss = crit(model(X)[:, :-1], X[:, 1:]); loss.backward(); opt.step()
    print(f"Epoch {e+1}: Done")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v5_models/hst_v5_trained.pt')
print("✓ HST v5 saved")
