# HST v5 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup; from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v5_hf', exist_ok=True)
os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2"); tokenizer.pad_token = tokenizer.eos_token
print("HST v5 - HF Language Dataset Training")

class RecursiveDescentLatticeAnalyzer(nn.Module):
    def __init__(self, d_model, depth=4):
        super().__init__()
        self.descent_layers = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(depth)])
        self.gates = nn.ModuleList([nn.Linear(d_model, 1) for _ in range(depth)])
        self.norms = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(depth)])
    def forward(self, x):
        for descent, gate, norm in zip(self.descent_layers, self.gates, self.norms):
            transformed = descent(x); gating = torch.sigmoid(gate(x))
            x = norm(x + transformed * gating)
        return x

class RecursiveHorizonPredictor(nn.Module):
    def __init__(self, d_model, horizon_depth=4):
        super().__init__()
        self.predictors = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(horizon_depth)])
        self.norms = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(horizon_depth)])
    def forward(self, x):
        predictions = []
        current = x
        for pred, norm in zip(self.predictors, self.norms):
            current = norm(pred(current))
            predictions.append(current)
        return sum(predictions) / len(predictions)

class HSTv5HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.analyzers = nn.ModuleList([RecursiveDescentLatticeAnalyzer(d_model) for _ in range(4)])
        self.horizon = RecursiveHorizonPredictor(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size)
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        for analyzer in self.analyzers: x = analyzer(x)
        x = self.horizon(x)
        return self.lm_head(x)

dataset = load_dataset("wikitext", "wikitext-2-v1", split="train[:10%]")
def tokenize_function(examples):
    return tokenizer(examples["text"], max_length=256, truncation=True, padding='max_length', return_tensors='pt')
tokenized = dataset.map(tokenize_function, batched=True, remove_columns=["text"])
tokenized.set_format('torch', columns=['input_ids'])

model = HSTv5HF().to(device); opt = torch.optim.Adam(model.parameters(), 1e-4); crit = nn.CrossEntropyLoss()
scheduler = get_linear_schedule_with_warmup(opt, 100, 600)
for e in range(3):
    for i in range(0, min(200, len(tokenized)), 8):
        batch_ids = torch.stack([tokenized[j]['input_ids'] for j in range(i, min(i+8, len(tokenized)))]).to(device)
        opt.zero_grad(); logits = model(batch_ids); loss = crit(logits[:, :-1].reshape(-1, 50257), batch_ids[:, 1:].reshape(-1))
        loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); opt.step(); scheduler.step()
        if i % 50 == 0: print(f"Epoch {e+1}, Step {i//8}: Loss {loss.item():.4f}")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v5_hf/hst_v5_hf.pt')
print("✓ HST v5 HF trained")
