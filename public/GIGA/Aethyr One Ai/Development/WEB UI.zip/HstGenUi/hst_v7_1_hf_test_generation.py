# HST v7.1 - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn, torch.nn.functional as F
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup; from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v7_1_hf', exist_ok=True)
os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2"); tokenizer.pad_token = tokenizer.eos_token

class FlashAttention(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        self.d_model = d_model; self.n_heads = n_heads; self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.out = nn.Linear(d_model, d_model)
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.out(attn.transpose(1, 2).reshape(B, S, D))

class SparseExpertRouter(nn.Module):
    def __init__(self, d_model, num_experts=8, top_k=2):
        super().__init__()
        self.router = nn.Linear(d_model, num_experts)
        self.experts = nn.ModuleList([nn.Linear(d_model, d_model) for _ in range(num_experts)])
        self.top_k = top_k
    def forward(self, x):
        logits = self.router(x); weights, indices = torch.topk(F.softmax(logits, dim=-1), self.top_k, dim=-1)
        output = torch.zeros_like(x)
        for k in range(self.top_k):
            for i in range(x.shape[0]):
                output[i] += self.experts[indices[i, k].item()](x[i]) * weights[i, k:k+1]
        return output

class HSTv71HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.attn_layers = nn.ModuleList([FlashAttention(d_model) for _ in range(4)])
        self.moe = SparseExpertRouter(d_model, 8, 2)
        self.lm_head = nn.Linear(d_model, vocab_size)
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        for attn in self.attn_layers: x = attn(x) + x
        x = self.moe(x) + x
        return self.lm_head(x)


# ==================== Load Model ====================
tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv71HF().to(device); opt = torch.optim.Adam(model.parameters(), 1e-4); crit = nn.CrossEntropyLoss()
model.to(device)

try:
    model.load_state_dict(torch.load("/content/drive/MyDrive/HST_Training/v7_1_hf/hst_v7_1_hf.pt", map_location=device))
    print("✓ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit(1)

model.eval()

# ==================== Generate ====================
def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

print("\n" + "="*60)
print("TESTING TEXT GENERATION")
print("="*60 + "\n")

for prompt in ["The future of AI", "Machine learning enables", "Innovation starts with"]:
    print(f"Prompt: \"{prompt}\"")
    print(f"Generated:\n{generate_text(prompt, max_tokens=80)}\n")
