# HST v8.2 - Latest with PagedKVCache & DynamicLatticeGate
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn; subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", "torch"])
import numpy as np; from sklearn.preprocessing import StandardScaler; from torch.utils.data import DataLoader, TensorDataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v8_2_models', exist_ok=True)
print("HST v8.2 Latest - Training")

class PagedKVCache(nn.Module):
    def __init__(self, block_size=256, max_blocks=100):
        super().__init__()
        self.blocks = {}; self.block_size = block_size; self.max_blocks = max_blocks
    def allocate(self): return torch.zeros(self.block_size, device='cuda')

class DynamicLatticeGate(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate = nn.Linear(dim, dim)
    def forward(self, x): return torch.sigmoid(self.gate(x)) * x

class HyperLatticeBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate = DynamicLatticeGate(dim)
        self.transform = nn.Linear(dim, dim)
        self.norm = nn.LayerNorm(dim)
    def forward(self, x): return self.norm(self.gate(self.transform(x)) + x)

class HSTv82(nn.Module):
    def __init__(self, dim=32, layers=4):
        super().__init__()
        self.embed = nn.Linear(1, dim)
        self.cache = PagedKVCache()
        self.blocks = nn.ModuleList([HyperLatticeBlock(dim) for _ in range(layers)])
        self.head = nn.Linear(dim, 1)
    
    def forward(self, x):
        x = self.embed(x.unsqueeze(-1) if len(x.shape)==2 else x)
        for block in self.blocks: x = block(x)
        return self.head(x)

data = np.array([np.linspace(0, 5, 100) + 2*np.sin(2*np.pi*np.arange(100)/50) + np.random.normal(0, 0.5, 100) for _ in range(1000)])
scaler = StandardScaler(); data = scaler.fit_transform(data.reshape(-1,1)).reshape(data.shape)
train_loader = DataLoader(TensorDataset(torch.FloatTensor(data[:800]).to(device)), batch_size=32, shuffle=True)
model = HSTv82().to(device); opt = torch.optim.Adam(model.parameters(), 1e-3); crit = nn.MSELoss()
for e in range(10):
    for X, in train_loader: opt.zero_grad(); loss = crit(model(X)[:,:-1], X[:,1:]); loss.backward(); opt.step()
    print(f"Epoch {e+1}: Done")
torch.save(model.state_dict(), '/content/drive/MyDrive/HST_Training/v8_2_models/hst_v8_2_trained.pt')
print("✓ HST v8.2 Latest saved")
