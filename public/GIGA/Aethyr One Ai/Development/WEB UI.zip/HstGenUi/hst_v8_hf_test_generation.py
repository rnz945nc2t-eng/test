# HST v8 Crystalline - HF Language Dataset Training
from google.colab import drive; drive.mount('/content/drive')
import subprocess, sys, os, torch, torch.nn as nn, torch.nn.functional as F, math
# torch transformers datasets pre-installed in Colab
from transformers import AutoTokenizer, get_linear_schedule_with_warmup
from datasets import load_dataset
device = torch.device('cuda'); os.makedirs('/content/drive/MyDrive/HST_Training/v8_hf', exist_ok=True)
print("HST v8 Crystalline - HF Language Dataset Training")

os.environ['HF_TOKEN'] = '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'
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token

class HyperbolicEmbedding(nn.Module):
    def __init__(self, d_model, curvature=1.0):
        super().__init__()
        self.c = curvature; self.embed = nn.Linear(1, d_model)
    def forward(self, x):
        emb = self.embed(x)
        norm = emb.norm(dim=-1, keepdim=True)
        max_norm = (1 - 1e-3) / math.sqrt(self.c)
        scale = torch.clamp(norm / max_norm, max=1.0)
        return emb / (scale + 1e-8)

class DiamondMixer(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.synthesis = nn.Sequential(nn.Linear(d_model, d_model*2), nn.GELU(), nn.Linear(d_model*2, d_model))
        self.analysis = nn.Sequential(nn.Linear(d_model, d_model*2), nn.GELU(), nn.Linear(d_model*2, d_model))
        self.norm = nn.LayerNorm(d_model)
    def forward(self, u):
        x = self.synthesis(u); y = self.analysis(u)
        z = (x + y) / 2; w = (y - x) / 2
        return self.norm(z + w + u)

class HebbianFastWeights(nn.Module):
    def __init__(self, d_model):
        super().__init__()
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.norm = nn.LayerNorm(d_model)
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, D).permute(2, 0, 1, 3)
        q, k, v = qkv[0], qkv[1], qkv[2]
        kv = torch.einsum('bsd,bse->bde', k, v) * 0.95
        out = torch.einsum('bsd,bde->bse', q, kv)
        lr = torch.sigmoid((q*k).sum(dim=-1, keepdim=True))
        return self.norm(x + out*lr)

class FastBlockSparseAttention(nn.Module):
    def __init__(self, d_model, n_heads=8):
        super().__init__()
        self.d_model = d_model; self.n_heads = n_heads; self.head_dim = d_model // n_heads
        self.qkv = nn.Linear(d_model, d_model*3, bias=False); self.out_proj = nn.Linear(d_model, d_model)
    def forward(self, x):
        B, S, D = x.shape
        qkv = self.qkv(x).reshape(B, S, 3, self.n_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn = F.scaled_dot_product_attention(q, k, v, is_causal=True)
        return self.out_proj(attn.transpose(1, 2).reshape(B, S, D))

class HSTv8HF(nn.Module):
    def __init__(self, vocab_size=50257, d_model=256):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, d_model)
        self.pos_embed = nn.Embedding(512, d_model)
        self.mixers = nn.ModuleList([DiamondMixer(d_model) for _ in range(4)])
        self.plasticity = HebbianFastWeights(d_model)
        self.attn = FastBlockSparseAttention(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size)
    
    def forward(self, input_ids):
        B, S = input_ids.shape
        x = self.embed(input_ids) + self.pos_embed(torch.arange(S, device=input_ids.device).unsqueeze(0))
        for mix in self.mixers: x = mix(x)
        x = self.attn(x)
        x = self.plasticity(x)
        return self.lm_head(x)


# ==================== Load Model ====================
tokenizer = AutoTokenizer.from_pretrained("gpt2")
model = HSTv8HF(vocab_size=50257, d_model=256).to(device)
model.to(device)

try:
    model.load_state_dict(torch.load("/content/drive/MyDrive/HST_Training/v8_hf/hst_v8_hf.pt", map_location=device))
    print("✓ Model loaded successfully")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit(1)

model.eval()

# ==================== Generate ====================
def generate_text(prompt, max_tokens=100, temperature=0.7, top_k=50):
    input_ids = tokenizer.encode(prompt, return_tensors='pt').to(device)
    with torch.no_grad():
        for _ in range(max_tokens):
            outputs = model(input_ids)
            logits = outputs[:, -1, :] / temperature
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = -float('Inf')
            probs = F.softmax(logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=-1)
            if next_token.item() == tokenizer.eos_token_id:
                break
    return tokenizer.decode(input_ids[0], skip_special_tokens=True)

print("\n" + "="*60)
print("TESTING TEXT GENERATION")
print("="*60 + "\n")

for prompt in ["The future of AI", "Machine learning enables", "Innovation starts with"]:
    print(f"Prompt: \"{prompt}\"")
    print(f"Generated:\n{generate_text(prompt, max_tokens=80)}\n")
